import React from 'react';

const ErrorPage = () => {
    return (
        <div>Nie ma takiej strony</div>
    );
}

export default ErrorPage;