import React from 'react';

const Cell = ({ type }) => (
  <div>cell</div>
)

export default Cell;