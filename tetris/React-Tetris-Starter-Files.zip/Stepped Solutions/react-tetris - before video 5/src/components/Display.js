import React from 'react';

const Display = ({ gameOver, text }) => (
  <div>{text}</div>
)

export default Display;