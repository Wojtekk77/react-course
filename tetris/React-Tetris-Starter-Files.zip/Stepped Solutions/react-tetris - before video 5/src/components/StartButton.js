import React from 'react';

const StartButton = ({ callback }) => (
  <div>Start Game</div>
)

export default StartButton;